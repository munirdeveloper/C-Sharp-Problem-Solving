﻿namespace CandyC2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int N = Convert.ToInt32(Console.ReadLine());
            string[] Manufacturer = new string[N];
            string[] Type = new string[N];
            int[] Price = new int[N];

            for (int i = 0; i < N; i++)
            {
                Manufacturer[i] = Console.ReadLine();
                Type[i] = Console.ReadLine();
                Price[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("#");

            // task 1

            string task1Manufacturer = "";
            string task1Type = "";
            int MostExpensive = Price[0];

            for (int i = 0; i < N; i++)
            {
                if (Price[i] > MostExpensive)
                {
                    task1Manufacturer = Manufacturer[i];
                    task1Type = Type[i];                   
                }
            }
            Console.WriteLine(task1Manufacturer + " " + task1Type);
            Console.WriteLine("#");

            // task 2

            bool task2 = false;

            List<string> companies = new List<string>();
            List<int> cnt = new List<int>();

            for (int i = 0; i < N; i++)
            {
                if (!companies.Contains(Manufacturer[i]))
                {
                    companies.Add(Manufacturer[i]);
                    cnt.Add(0);
                }
            }
            for (int i = 0; i < companies.Count; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    if (Manufacturer[j] == companies[i])
                    {
                        cnt[i]++;
                    }
                }
            }

            for (int i = 0; i < companies.Count; i++)
            {
                if (cnt[i] == 1)
                {
                    task2 = true;
                    Console.WriteLine(companies[i]);
                    break;
                }
            }
            if (!task2)
            {
                Console.WriteLine("NONE");
            }

            // task 3

            Console.WriteLine("#");

            foreach (string comp in  companies)
            {
                Console.WriteLine(comp);
            }

            // task 4

            Console.WriteLine("#");

            List<string> Allcandies = new List<string>();
            List<int> candyCnt = new List<int>();

            for (int i = 0; i < N; i++)
            {
                if (!Allcandies.Contains(Type[i]))
                {
                    Allcandies.Add(Type[i]);
                    candyCnt.Add(0);
                }
            }

            for (int i = 0; i < Allcandies.Count; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    if (Type[j] == Allcandies[i])
                    {
                        candyCnt[i]++;
                    }
                }
            }

            int maxcandy = 0;
            string maxType = "";

            for (int i = 0; i < Allcandies.Count; i++)
            {
                if (candyCnt[i] > maxcandy)
                {
                    maxcandy = candyCnt[i];
                    maxType = Allcandies[i];
                }
            }

            Console.WriteLine(maxType);
            Console.WriteLine("#");

            // task 5

            string companyTask5 = "";
            bool task5 = false;

            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    if (Type[i] == Type[j] && Price[i] < Price[j])
                    {
                        task5 = true;
                        companyTask5 = Manufacturer[i];
                        break;                       
                    }
                }
            }
            Console.WriteLine(companyTask5);

            if (!task5)
            {
                Console.WriteLine("NONE");
            }


        }
    }
}