﻿namespace b2_task_Munir
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int N = Convert.ToInt32(Console.ReadLine());
            int[] rank = new int[N];
            int[] minutes = new int[N];
            int[] seconds = new int[N];         

            for (int i = 0; i < N; i++)
            {
                string input = Console.ReadLine();
                rank[i] = Convert.ToInt32(input.Split(" ")[0]);
                minutes[i] = Convert.ToInt32(input.Split(" ")[1]);
                seconds[i] = Convert.ToInt32(input.Split(" ")[2]);        
                
            }

            int[] sumofseconds = new int[N];

            for (int i = 0;i < N; i++)
            {
                sumofseconds[i] = (minutes[i] * 60) + seconds[i];
            }

            int count = 0;

            for (int i = 0; i < N-1; i++)
            {
                if (sumofseconds[i+1] < sumofseconds[i])
                {
                    count++;
                }
            }

            Console.WriteLine(count);




        }
    }
}